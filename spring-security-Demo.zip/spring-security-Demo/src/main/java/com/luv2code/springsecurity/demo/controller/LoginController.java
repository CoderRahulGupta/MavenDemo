package com.luv2code.springsecurity.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {

	@GetMapping("/")
	public String showMyLoginPage() {
		
		// return "plain-login";

		return "fancy-login";
		
	}
	
	/*
	 * @RequestMapping(value="/userdata", method=RequestMethod.POST,produces =
	 * MediaType.APPLICATION_JSON_VALUE) public Object
	 * recoverPass(@RequestParam("username") String
	 * username,@RequestParam("password") String password) { //do smthin
	 * System.out.println("Username is"+username);
	 * System.out.println("Password is"+password);
	 * 
	 * return "rahul"; }
	 */
	
	
	@RequestMapping(value="/userdata")
	@ResponseBody
	public String recoverPass(@RequestParam("username") String username,@RequestParam("password") String password,
			@RequestParam("domain") String domain) {
	    //do smthin
		System.out.println("Username is"+username);
		System.out.println("Password is"+password);
		System.out.println("Domain is"+domain);
		return "rahul";
	}
}
